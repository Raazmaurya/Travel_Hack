This directory will be used to house MongoDB data for the application
